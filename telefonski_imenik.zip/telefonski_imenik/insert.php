<html>
    <head>
        <title>Telefonski imenik</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div id="okvir">
            <div id="pretraga">
                <img src='img/search.png' alt='Slika'>
                <form action="#" method="GET">
                    <input type="text" name="ime" placeholder="Ime..">
                    <input type="text" name="prezime" placeholder="Prezime..">
                    <input type="text" name="tel" placeholder="Tel..">
                    <input type="submit" value="Dodaj"><br/>
                </form>
                <?php include_once 'inc/linkovi.php'; ?>
            </div>
            <?php
                include_once 'inc/baza.php';
                if(isset($_GET['ime'],$_GET['prezime'],$_GET['tel'])){
                    if(!empty($_GET['ime']) && !empty($_GET['prezime']) && !empty($_GET['tel'])){
                        $ime = trim($_GET['ime']);
                        $prezime = trim($_GET['prezime']);
                        $tel = trim($_GET['tel']);
                        $query = "INSERT INTO tabela (ime,prezime,telefon) VALUES ('{$ime}','{$prezime}','{$tel}')";
                        mysqli_query($conn,$query);
                        if(mysqli_affected_rows($conn) > 0){
                            echo "Uspesno.";
                        }else{
                            echo mysqli_error($conn);
                        }
                    }
                }
            ?>
        </div>
    </body>
</html>