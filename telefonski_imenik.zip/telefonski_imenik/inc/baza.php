<?php

$conn = mysqli_connect("localhost","root","","test");

if(!$conn){
    die("Nema konekcije." . mysqli_connect_error($conn));
}else{
    echo "Uspesna konakcija.";
}