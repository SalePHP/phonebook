
<a href="index.php">Trazi</a><br /><a href="insert.php">Dodaj</a><br /><a href="delete.php">Ukloni</a>