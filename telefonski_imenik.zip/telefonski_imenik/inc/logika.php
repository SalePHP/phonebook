<?php
include_once 'baza.php';


if(isset($_GET['kriterijum'])){
    $kriterijum = trim($_GET['kriterijum']);
    if(!empty($kriterijum)){
        $query = "SELECT * FROM tabela WHERE ime LIKE '%{$kriterijum}%' OR prezime LIKE '%{$kriterijum}%'";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) > 0){
            while($r = mysqli_fetch_assoc($result)){
                echo "<div id='rezultat'>";
                echo "<img src='img/User.png'/>";
                echo "Ime: ".$r['ime']." <br />";
                echo "Prezime: ".$r['prezime']." <br />";
                echo "Tel: ".$r['telefon']." <br />";
                echo "</div>";
            }
        }
    }else{
        echo 'Prosledite kriterijum za pretragu.';
    }
}
?>