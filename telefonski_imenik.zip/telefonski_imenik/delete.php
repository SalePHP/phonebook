<html>
    <head>
        <title>Telefonski imenik</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div id="okvir">
            <div id="pretraga">
                <img src='img/search.png' alt='Slika'>
                <!--
                <form action="#" method="GET">
                    <input type="text" name="id" placeholder="ID..">
                    <input type="submit" value="Ukloni">
                </form>
                -->
                <?php include_once 'inc/linkovi.php'; ?>
            </div>
            <?php
                include_once 'inc/baza.php';
                
                if(isset($_GET['id'])){
                    if(!empty($_GET['id'])){
                        $id = trim($_GET['id']);
                        $query = "DELETE FROM tabela WHERE id = {$id}";
                        mysqli_query($conn,$query);
                        if(mysqli_affected_rows($conn) > 0){
                            echo "Uspesno.";
                        }else{
                            echo mysqli_error($conn);
                        }
                    }
                }
                
                $query = "SELECT * FROM tabela";
                $result = mysqli_query($conn, $query);
                if(mysqli_num_rows($result) > 0){
                    while($r = mysqli_fetch_assoc($result)){
                        echo "<div id='rezultat'>";
                        echo "<img src='img/User.png'/>";
                        echo "Ime: ".$r['ime']." <br />";
                        echo "Prezime: ".$r['prezime']." <br />";
                        echo "Tel: ".$r['telefon']." <br />";
                        echo "<a href='delete.php?id=".$r['id']."'>Ukloni</a>";
                        echo "</div>";
                    }
                }
            ?>
        </div>
    </body>
</html>